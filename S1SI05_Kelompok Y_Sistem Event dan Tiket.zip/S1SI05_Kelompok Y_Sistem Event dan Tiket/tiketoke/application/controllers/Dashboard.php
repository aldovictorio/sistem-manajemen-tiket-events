<?php
  class Dashboard extends CI_Controller {

    public function index() {
        $this->load->view('header');
        $this->load->view('Home');
        $this->load->view('footer');
    }
}
