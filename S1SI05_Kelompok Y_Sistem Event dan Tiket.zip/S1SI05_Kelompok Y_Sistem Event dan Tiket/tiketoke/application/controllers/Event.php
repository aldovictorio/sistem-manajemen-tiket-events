<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Event extends CI_Controller
{
    public function __construct()
    {
      parent::__construct();
      $this->load->model('Event_model');
      $this->load->helper('custom_helper');

    }

    public function index()
    {
      $data['event'] = $this->Event_model->tampil();
      
      $this->load->view('header');
      $this->load->view('event_view', $data);
      $this->load->view('footer');
    }

    public function tambah() {
      $inputan = $this->input->post();

      if ($inputan) {
        $this->Event_model->tambah($inputan);
        $this->session->set_flashdata('pesan_sukses', 'Event Berhasil Ditambah!');
        redirect('event', 'refresh');     
      }

      $this->load->view('header');
      $this->load->view('event_tambah');
      $this->load->view('footer');        
    }

    public function ubah($id){
        $data['event'] = $this->Event_model->detail($id); 
    
        if ($this->input->post()) {
          $inputan = [
            'nama_event' => $this->input->post('nama_event'),
            'tanggal_event' => $this->input->post('tanggal_event'),
            'lokasi_event' => $this->input->post('lokasi_event')
          ];
  
          $this->Event_model->ubah($inputan, $id);
          $this->session->set_flashdata('pesan_sukses', 'Event Berhasil Diubah!');
          redirect('event'); 
        }
    
        $this->load->view('header');
        $this->load->view('event_ubah', $data); 
        $this->load->view('footer');
    }

    public function hapus($event_id) {
      $this->Event_model->hapus($event_id);
      
      $this->session->set_flashdata('pesan_sukses', 'Event telah terhapus');
      redirect('event', 'refresh');
    }
    
}
