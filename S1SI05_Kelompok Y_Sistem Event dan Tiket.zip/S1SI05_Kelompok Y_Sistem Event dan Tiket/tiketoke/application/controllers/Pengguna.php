<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengguna extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('Pengguna_model');
    }

    public function index() {
        $data['pengguna'] = $this->Pengguna_model->tampil();

        $this->load->view('header');
        $this->load->view('pengguna_view', $data);
        $this->load->view('footer');        
    }

    public function tambah() {
      $data['pengguna'] = $this->Pengguna_model->tampil();
  
      $inputan = $this->input->post();
      if ($inputan) {
          $this->Pengguna_model->tambah($inputan);
          $this->session->set_flashdata('pesan_sukses', 'Pengguna Berhasil Ditambah!');
          redirect('pengguna', 'refresh');
      }
  
      $this->load->view('header');
      $this->load->view('pengguna_tambah', $data);
      $this->load->view('footer');        
    }
    
    public function ubah($id)
    {
      $data['pengguna'] = $this->Pengguna_model->detail($id);
  
      if ($this->input->post()) {
          $inputan = [
              'nama' => $this->input->post('nama'),
              'nomor_telepon' => $this->input->post('nomor_telepon'),
              'email' => $this->input->post('email'),
          ];
  
          $this->Pengguna_model->ubah($inputan, $id);
          $this->session->set_flashdata('pesan_sukses', 'Pengguna Berhasil Diubah!');
          redirect('pengguna');
        }
    
        $this->load->view('header');
        $this->load->view('pengguna_ubah', $data);
        $this->load->view('footer');
    }
    

    public function hapus($pengguna_id) {
      $this->Pengguna_model->hapus($pengguna_id);
      
      $this->session->set_flashdata('pesan_sukses', 'Pengguna telah terhapus');
      redirect('pengguna', 'refresh');
    }
}
