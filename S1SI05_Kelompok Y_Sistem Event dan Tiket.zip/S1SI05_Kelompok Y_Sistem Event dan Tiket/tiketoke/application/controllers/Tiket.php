<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tiket extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->model('Tiket_model');
        $this->load->model('Event_model');
        $this->load->helper('custom_helper');
    }

    public function index() {
        $data['tiket'] = $this->Tiket_model->tampil();

        $this->load->view('header');
        $this->load->view('tiket_view', $data);
        $this->load->view('footer');
    }

    public function tambah() {
      $data['event'] = $this->Event_model->tampil();
      $data['kategori_tiket'] = $this->db->get('kategori_tiket')->result_array(); 
  
      $inputan = $this->input->post();
      if ($inputan) {
          $this->Tiket_model->tambah($inputan);
          $this->session->set_flashdata('pesan_sukses', 'Tiket Berhasil Ditambah!');
          redirect('tiket', 'refresh');     
      }
  
      $this->load->view('header');
      $this->load->view('tiket_tambah', $data);
      $this->load->view('footer');        
    }
    
    public function ubah($id) {
        $data['tiket'] = $this->Tiket_model->detail($id);
        $data['event'] = $this->Event_model->tampil();
        $data['kategori_tiket'] = $this->db->get('kategori_tiket')->result_array(); 
    
        if ($this->input->post()) {
            $inputan = [
                'nama_tiket' => $this->input->post('nama_tiket'),
                'harga' => $this->input->post('harga_tiket'),
                'kategori_id' => $this->input->post('kategori_id'), 
                'event_id' => $this->input->post('event_id'),
            ];
    
            $this->Tiket_model->ubah($inputan, $id);
            $this->session->set_flashdata('pesan_sukses', 'Tiket Berhasil Diubah!');
            redirect('tiket');
        }
    
        $this->load->view('header');
        $this->load->view('tiket_ubah', $data);
        $this->load->view('footer');
    }
    
    

    public function hapus($tiket_id) {
      $this->Tiket_model->hapus($tiket_id);
      
      $this->session->set_flashdata('pesan_sukses', 'Tiket telah terhapus');
      redirect('tiket', 'refresh');
    }
}
