<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pembayaran extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Pembayaran_model');
    $this->load->model('Event_model');
    $this->load->model('Tiket_model');
    $this->load->model('Pengguna_model');
    $this->load->helper('custom_helper');
  }

  public function index()
  {
    $data['pembayaran'] = $this->Pembayaran_model->tampil();

    $this->load->view('header');
    $this->load->view('pembayaran_view', $data);
    $this->load->view('footer');
  }

  public function tambah()
  {
    $data['event'] = $this->Event_model->tampil();
    $data['tiket'] = $this->Tiket_model->tampil();
    $data['pengguna'] = $this->Pengguna_model->tampil();

    $inputan = $this->input->post();
    if ($inputan) {
      $this->Pembayaran_model->tambah($inputan);
      $this->session->set_flashdata('pesan_sukses', 'Pembayaran Berhasil Ditambah!');
      redirect('pembayaran', 'refresh');
    }

    $this->load->view('header');
    $this->load->view('pembayaran_tambah', $data);
    $this->load->view('footer');
  }

  public function ubah($id)
  {
    $data['pembayaran'] = $this->Pembayaran_model->detail($id);
    $data['tiket'] = $this->Tiket_model->tampil();
    $data['pengguna'] = $this->Pengguna_model->tampil();

    if ($this->input->post()) {
      $inputan = [
        'pengguna_id' => $this->input->post('pengguna_id'),
        'tiket_id' => $this->input->post('tiket_id'),
        'tanggal_pembayaran' => $this->input->post('tanggal_pembayaran'),
        'jumlah_pembayaran' => $this->input->post('jumlah_pembayaran'),
        'metode_pembayaran' => $this->input->post('metode_pembayaran'),
      ];

      $this->Pembayaran_model->ubah($inputan, $id);
      $this->session->set_flashdata('pesan_sukses', 'Pembayaran Berhasil Diubah!');
      redirect('pembayaran');
    }

    $this->load->view('header');
    $this->load->view('pembayaran_ubah', $data);
    $this->load->view('footer');
  }


  public function hapus($pembayaran_id)
  {
    $this->Pembayaran_model->hapus($pembayaran_id);

    $this->session->set_flashdata('pesan_sukses', 'Pembayaran telah terhapus');
    redirect('pembayaran', 'refresh');
  }
}
