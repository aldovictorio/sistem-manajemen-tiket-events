<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna_model extends CI_Model
{
    public function tampil() {
      return $this->db->get('pengguna')->result_array();
    }

    public function detail($id) {
      return $this->db->get_where('pengguna', ['pengguna_id' => $id])->row_array();      
    }
    
    public function tambah($inputan) {
        $this->db->insert('pengguna', $inputan);
    }
    
    public function ubah($inputan, $id) {
  
      $this->db->where('pengguna.pengguna_id', $id);      
      $this->db->update('pengguna', $inputan);
    }
  
    function hapus($pengguna_id) {
      $this->db->where('pengguna.pengguna_id', $pengguna_id);
      $this->db->delete('pengguna');
    }
}