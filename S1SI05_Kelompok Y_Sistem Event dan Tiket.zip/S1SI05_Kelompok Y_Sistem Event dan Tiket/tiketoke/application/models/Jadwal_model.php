<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jadwal_model extends CI_Model
{
    public function get_all_jadwal()
    {
        return $this->db->get('jadwal')->result_array();
    }
}
