<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tiket_model extends CI_Model
{
  public function tampil()
  {
      $this->db->select('kategori_tiket.nama_kategori, tiket.*, events.nama_event, events.tanggal_event');
      $this->db->from('kategori_tiket');
      $this->db->join('tiket', 'kategori_tiket.kategori_id = tiket.kategori_id', 'right');
      $this->db->join('events', 'tiket.event_id = events.event_id', 'left');
  
      $query = $this->db->get();
      
      return $query->result_array();
  }
  
  public function detail($id) {
    return $this->db->get_where('tiket', ['tiket_id' => $id])->row_array();      
  }
  
  public function tambah($inputan) {
      $this->db->insert('tiket', $inputan);
  }
  
  public function ubah($inputan, $id) {

    $this->db->where('tiket.tiket_id', $id);      
    $this->db->update('tiket', $inputan);
  }

  function hapus($tiket_id) {
    $this->db->where('tiket.tiket_id', $tiket_id);
    $this->db->delete('tiket');
  }

}
