<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Event_model extends CI_Model
{
    public function tampil() {
      return $this->db->get('events')->result_array();
    }

    public function detail($id) {
      return $this->db->get_where('events', ['event_id' => $id])->row_array();      
    }
    
    function tambah($inputan) {
      $this->db->insert('events', $inputan);
    }

    public function ubah($inputan, $id) {

      $this->db->where('events.event_id', $id);      
      $this->db->update('events', $inputan);
    }

    function hapus($event_id) {
      $this->db->where('events.event_id', $event_id);
      $this->db->delete('events');
    }
}
