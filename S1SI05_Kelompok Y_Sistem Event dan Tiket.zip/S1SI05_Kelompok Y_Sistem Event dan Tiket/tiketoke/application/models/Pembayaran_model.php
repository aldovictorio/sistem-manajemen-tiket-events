<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pembayaran_model extends CI_Model
{
  public function tampil()
  {
      $this->db->select('pengguna.nama, pembayaran.*, tiket.nama_tiket, events.nama_event');
      $this->db->from('pengguna');
      $this->db->join('pembayaran', 'pengguna.pengguna_id = pembayaran.pengguna_id', 'right');
      $this->db->join('tiket', 'pembayaran.tiket_id = tiket.tiket_id', 'left');
      $this->db->join('events', 'tiket.event_id = events.event_id', 'left');
  
      $query = $this->db->get();
      
      return $query->result_array();
  }

  public function detail($id) {
    return $this->db->get_where('pembayaran', ['pembayaran_id' => $id])->row_array();      
  }
  
  public function tambah($inputan) {
    $data = [
      'pengguna_id' => $inputan['pengguna_id'],
      'tiket_id' => $inputan['tiket_id'],
      'tanggal_pembayaran' => $inputan['tanggal_pembayaran'],
      'jumlah_pembayaran' => $inputan['jumlah_pembayaran'],
      'metode_pembayaran' => $inputan['metode_pembayaran']
    ];

    $this->db->insert('pembayaran', $data);
  }
  
  public function ubah($inputan, $id) {

    $this->db->where('pembayaran.pembayaran_id', $id);      
    $this->db->update('pembayaran', $inputan);
  }

  function hapus($pembayaran_id) {
    $this->db->where('pembayaran.pembayaran_id', $pembayaran_id);
    $this->db->delete('pembayaran');
  }
  
}
