<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Pembayaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
      body {
        background: url('https://source.unsplash.com/1600x900/?nature') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif; 
      }
      .container {
        background-color: rgb(74, 5, 222); 
        padding: 30px;
        border-radius: 10px;
        margin-top: 20px;
      }
      .card-header {
        background-color: #f59f00;
        color: white;
      }
      .btn-custom {
        background-color: green;
        color: white;
        border: none;
      }
      .btn-custom:hover {
        background-color: green;
      }
      .btn-back {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      .btn-back:hover {
        background-color: #2980b9;
      } 
      .table th, .table td {
        text-align: center;
      }
      .card {
        border-radius: 10px;
      }
    </style>
  </head>
  <body>
    <div class="container mt-5">
      <h1 class="mb-4 text-center text-white">Daftar Pembayaran</h1>
      <a href="<?= base_url('Dashboard') ?>" class="btn btn-back">
        <i class="fas fa-home"></i> Kembali ke Home
      </a>
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <span class="h5">Daftar Pembayaran</span>
          <a href="<?= base_url('pembayaran/tambah') ?>" class="btn btn-custom btn-sm">
            <i class="fas fa-plus"></i> Tambah Data
          </a>
        </div>
        
        <div class="card-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead class="thead-dark">
              <tr>
                <th>ID</th>
                <th>Nama Pembeli</th>
                <th>Nama Tiket</th>
                <th>Nama Event</th>
                <th>Tanggal Pembayaran</th>
                <th>Jumlah Pembayaran</th>
                <th>Metode Pembayaran</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pembayaran as $key => $value): ?>
                <tr>
                  <td><?php echo $key + 1; ?></td>
                  <td><?php echo $value['nama']; ?></td>
                  <td><?php echo $value['nama_tiket']; ?></td>
                  <td><?php echo $value['nama_event']; ?></td>
                  <td><?php echo formatDateIndonesian($value['tanggal_pembayaran']); ?></td>
                  <td><?php echo number_format($value['jumlah_pembayaran']); ?></td>
                  <td><?php echo $value['metode_pembayaran']; ?></td>
                  <td>
                    <a href="<?php echo base_url('pembayaran/ubah/' . $value['pembayaran_id']) ?>" class="btn btn-primary btn-sm">
                      <i class="fas fa-edit"></i> Ubah
                    </a>
                    <a href="<?php echo base_url('pembayaran/hapus/' . $value['pembayaran_id']) ?>" class="btn btn-danger btn-sm">
                      <i class="fas fa-trash-alt"></i> Hapus
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
