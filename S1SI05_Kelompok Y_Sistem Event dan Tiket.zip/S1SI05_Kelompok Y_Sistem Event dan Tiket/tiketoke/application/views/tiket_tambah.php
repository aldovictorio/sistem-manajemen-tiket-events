<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Tiket</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
      body {
        background: url('https://source.unsplash.com/1600x900/?ticket') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
      }

      .container {
        background-color: rgb(74, 5, 222); 
        padding: 30px;
        border-radius: 10px;
        margin-top: 50px;
      }

      .btn-custom {
        background-color: #28a745;
        color: white;
        border: none;
      }

      .btn-custom:hover {
        background-color: #218838; 
      }

      .btn-back {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        margin-bottom: 20px;
      }

      .btn-back:hover {
        background-color: #2980b9;
      }

      .form-control {
        border-radius: 5px;
        border-color: #ddd;
      }

      label {
        font-weight: bold;
        color: white;
      }

      .error {
        color: red;
        font-weight: bold;
        text-align: center;
        margin-bottom: 15px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 class="mb-4 text-center text-white">Tambah Tiket</h1>
      <a href="<?= base_url('tiket') ?>" class="btn btn-back mt-3">
        <i class="fas fa-arrow-left"></i> Kembali ke Daftar Tiket
      </a>

      <div>
        <?php if (!empty($error)) : ?>
          <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post">
          <div class="mb-3">
            <label for="nama_tiket" class="text-white">Nama Tiket</label>
            <input type="text" name="nama_tiket" id="nama_tiket" class="form-control" required>     
          </div>

          <div class="mb-3">
            <label class="text-white">Nama Event</label>
            <select class="form-control form-select" name="event_id">
              <option value="">Pilih</option>
              <?php foreach ($event as $key => $value) : ?>
                <option value="<?php echo $value['event_id'] ?>">
                    <?php echo $value['nama_event'] ?>
                </option>
              <?php endforeach ?>
            </select>
          </div>

          <div class="mb-3">
            <label for="harga" class="text-white">Harga Tiket</label>
            <input type="number" name="harga" id="harga" class="form-control" required>     
          </div>

          <div class="form-group">
            <label for="kategori_id" class="text-white">Kategori Tiket</label>
            <select class="form-control mb-3" name="kategori_id">
              <?php foreach ($kategori_tiket as $kategori): ?>
                <option value="<?= $kategori['kategori_id']; ?>"><?= $kategori['nama_kategori']; ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <button type="submit" class="btn btn-custom">Simpan</button>
        </form>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
