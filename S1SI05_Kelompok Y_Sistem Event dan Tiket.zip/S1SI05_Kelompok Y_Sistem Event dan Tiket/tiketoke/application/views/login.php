<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #4a05de, #f59f00);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            margin: 0;
        }
        .login-card {
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 25px blue;
            padding: 3rem; 
            width: 100%;
            max-width: 500px; 
        }
        h1 {
            font-size: 2rem;
            font-weight: bold;
            color: #f59f00;
        }
        .sub-title {
            color: #4a05de;
            font-size: 2rem;
            font-weight: bold;
            margin-top: -10px;  
            text-align: center; 
        }
        .btn-primary {
            background-color: #4a05de;
            border: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #f59f00;
            color: #fff;
        }
        .form-control {
            border: 2px solid #ddd;
            border-radius: 10px;
            font-size: 1.1rem; 
            padding: 0.75rem;
        }
        .form-control:focus {
            border-color: #4a05de;
            box-shadow: 0 0 0 0.2rem rgba(74, 5, 222, 0.25);
        }
        form {
            text-align: left; 
        }
        label {
            font-weight: bold;
            color: #333;
            font-size: 1.2rem; 
        }
        small.text-danger {
            color: red;
        }
    </style>
</head>
<body>

  <div class="login-card">
    <h1 class="sub-title">Login Admin Event</h1>
    <h5 class="sub-title">Tiket Oke</h5>
    <form method="post">
      <div class="mb-4">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" class="form-control" 
               value="<?php echo set_value('username'); ?>" placeholder="Masukkan username" required>
        <small class="text-danger"><?php echo form_error('username'); ?></small>
      </div>

      <div class="mb-4">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" class="form-control" 
               value="<?php echo set_value('password'); ?>" placeholder="Masukkan password" required>
        <small class="text-danger"><?php echo form_error('password'); ?></small>
      </div>

      <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
  </div>

</body>
</html>
