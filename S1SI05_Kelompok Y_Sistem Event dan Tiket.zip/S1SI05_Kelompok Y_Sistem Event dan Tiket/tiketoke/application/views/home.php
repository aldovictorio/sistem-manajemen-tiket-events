<div class="content">
  <div class="container">
    <h5>Dashboard Admin Event Tiket Oke</h5>
    <p class="lead">
      Mari Kelola Tiket dengan Mudah
    </p>

    <div class="row mb-4">
      <div class="col-md-3">
        <div class="card text-white bg-primary mb-3">
          <div class="card-body">
            <h5 class="card-title">Total Pembeli</h5>
            <p class="card-text">1,245</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-success mb-3">
          <div class="card-body">
            <h5 class="card-title">Event Aktif</h5>
            <p class="card-text">12</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-warning mb-3">
          <div class="card-body">
            <h5 class="card-title">Tiket Terjual</h5>
            <p class="card-text">3,450</p>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card text-white bg-danger mb-3">
          <div class="card-body">
            <h5 class="card-title">Pendapatan</h5>
            <p class="card-text">Rp 45.000.000</p>
          </div>
        </div>
      </div>
    </div>

    <div id="grafik-penjualan" class="mb-4"></div>

  <script>
    Highcharts.chart('grafik-penjualan', {
      chart: { type: 'line' },
      title: { text: 'Penjualan Tiket Bulanan' },
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
      },
      yAxis: {
        title: { text: 'Jumlah Tiket Terjual' }
      },
      series: [{
        name: 'Tiket Terjual',
        data: [29, 71, 106, 129, 144, 176, 135, 148, 216, 194, 95, 54]
      }]
    });
  </script>
</div>
