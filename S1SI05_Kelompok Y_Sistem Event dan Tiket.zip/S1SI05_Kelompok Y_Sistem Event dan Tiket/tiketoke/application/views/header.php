<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin TiketOke</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/styles/admin/sidebar.css') ?>">

    <style>
      body {
        background-color: #f4f7fc;
      }
      .sidebar {
        height: 100vh;
        background-color:rgb(74, 5, 222);
        color: white;
        position: fixed;
        width: 250px;
        padding-top: 30px;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
      }

      .sidebar h2 {
        font-size: 24px;
        font-weight: 600;
        color: #f59f00;
        text-align: center;
        margin-bottom: 30px;
      }

      .sidebar .navbar-nav .nav-item {
        margin-bottom: 15px;
      }

      .sidebar .navbar-nav .nav-item .nav-link {
        color: white;
        font-size: 18px;
        padding: 12px 20px;
        border-radius: 5px;
        transition: background-color 0.3s;
      }

      .sidebar .navbar-nav .nav-item .nav-link:hover {
        background-color: #f59f00;
        color: white;
      }

      .sidebar .navbar-nav .nav-item.active .nav-link {
        background-color: #f59f00;
        color: white;
      }

      .sidebar .navbar-nav .nav-item i {
        margin-right: 10px;
      }

      .sidebar .nav-item:last-child {
        position: absolute;
        bottom: 20px;
        width: 90%;
      }

      .sidebar .nav-item:last-child .nav-link {
        background-color: #e74c3c;
        color: white;
        font-weight: 600;
      }

      .sidebar .nav-item:last-child .nav-link:hover {
        background-color: #c0392b;
      }

      .sidebar .nav-item .nav-link.active {
        font-weight: bold;
      }
      .sidebar {
        transition: all 0.3s ease-in-out;
      }

      .sidebar h2 span {
        color: #f59f00;
      }
    </style>
  </head>
  <body>
    <div class="sidebar">
      <h2 class="text-left mb-3 mx-2">Event Tiket <span>Oke</span></h2>

      <ul class="navbar-nav">
        <li class="nav-item">
          <a href="<?php echo base_url('dashboard') ?>" class="nav-link <?php echo (current_url() == base_url('dashboard') ? 'active' : ''); ?>">
            <i class="fas fa-home"></i> Home
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url('pengguna') ?>" class="nav-link <?php echo (current_url() == base_url('pengguna') ? 'active' : ''); ?>">
            <i class="fas fa-users"></i> Pembeli
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url('event') ?>" class="nav-link <?php echo (current_url() == base_url('event') ? 'active' : ''); ?>">
            <i class="fas fa-calendar-alt"></i> Events
          </a>
        </li>
        
        <li class="nav-item">
          <a href="<?php echo base_url('tiket') ?>" class="nav-link <?php echo (current_url() == base_url('tiket') ? 'active' : ''); ?>">
            <i class="fas fa-ticket-alt"></i> Tiket
          </a>
        </li>
      
        <li class="nav-item">
          <a href="<?php echo base_url('pembayaran') ?>" class="nav-link <?php echo (current_url() == base_url('pembayaran') ? 'active' : ''); ?>">
            <i class="fas fa-credit-card"></i> Pembayaran
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url('logout') ?>" class="nav-link <?php echo (current_url() == base_url('logout') ? 'active' : ''); ?>">
            <i class="fas fa-sign-out-alt"></i> Logout
          </a>
        </li>
      </ul>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
