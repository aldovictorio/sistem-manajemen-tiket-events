<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Pembeli</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
      body {
        background: url('https://source.unsplash.com/1600x900/?people') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
      }
      .container {
        background-color: rgb(74, 5, 222); 
        padding: 30px;
        border-radius: 10px;
        margin-top: 50px;
      }
      .card-header {
        background-color: #f59f00;
        color: white;
      }
      .btn-custom {
        background-color: #28a745; 
        color: white;
        border: none;
      }
      .btn-custom:hover {
        background-color: #218838; 
      }
      .btn-back {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      .btn-back:hover {
        background-color: #2980b9;
      }
      .form-control {
        border-radius: 5px;
        border-color: #ddd;
      }
      label {
        font-weight: bold;
      }
      .error {
        color: red;
        font-weight: bold;
        text-align: center;
        margin-bottom: 15px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 class="mb-4 text-center text-white">Tambah Pembeli</h1>
      <?php if (!empty($error)) : ?>
        <p class="error"><?php echo $error; ?></p>
      <?php endif; ?>
      <a href="<?= base_url('pengguna') ?>" class="btn btn-back">
        <i class="fas fa-arrow-left"></i> Kembali ke Daftar Pembeli
      </a>

      <form method="post">
        <div class="mb-3">
          <label for="nama" class="text-white">Nama Pembeli</label>
          <input type="text" name="nama" id="nama" class="form-control" required>     
        </div>

        <div class="mb-3">
          <label for="nomor_telepon" class="text-white">Nomor Telepon Pembeli</label>
          <input type="text" name="nomor_telepon" id="nomor_telepon" class="form-control" required>     
        </div>

        <div class="mb-3">
          <label for="email" class="text-white">Email Pembeli</label>
          <input type="email" name="email" id="email" class="form-control" required>     
        </div>

        <button type="submit" class="btn btn-custom">Simpan</button>
      </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
