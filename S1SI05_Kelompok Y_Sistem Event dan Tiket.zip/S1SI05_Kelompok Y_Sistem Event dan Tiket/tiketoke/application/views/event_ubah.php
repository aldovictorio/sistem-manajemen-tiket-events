<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ubah Event</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
      body {
        background: url('https://source.unsplash.com/1600x900/?event') no-repeat center center fixed;
        background-size: cover;
        font-family: Arial, sans-serif;
      }
      .container {
        background-color: rgb(74, 5, 222); 
        padding: 30px;
        border-radius: 10px;
        margin-top: 50px;
      }
      .card-header {
        background-color: #f59f00;
        color: white;
      }
      .btn-custom {
        background-color: #28a745;
        color: white;
        border: none;
      }
      .btn-custom:hover {
        background-color: #218838; 
      }
      .btn-back {
        background-color: #3498db;
        color: white;
        border-radius: 5px;
        margin-bottom: 20px;
      }
      .btn-back:hover {
        background-color: #2980b9;
      }
      .form-control {
        border-radius: 5px;
        border-color: #ddd;
      }
      
      label {
        font-weight: bold;
      }

      .error {
        color: red;
        font-weight: bold;
        text-align: center;
        margin-bottom: 15px;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h1 class="mb-4 text-center text-white">Ubah Event</h1>
      <a href="<?= base_url('event') ?>" class="btn btn-back mt-3">
        <i class="fas fa-arrow-left"></i> Kembali ke Daftar Event
      </a>

      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label for="nama_event" class="text-white">Nama Event</label>
          <input type="text" name="nama_event" id="nama_event" class="form-control" value="<?php echo $event['nama_event']; ?>" required>     
        </div>

        <div class="mb-3">
          <label for="tanggal_event" class="text-white">Tanggal Event</label>
          <input type="date" name="tanggal_event" id="tanggal_event" class="form-control" value="<?php echo $event['tanggal_event']; ?>" required>     
        </div>

        <div class="mb-3">
          <label for="lokasi_event" class="text-white">Lokasi Event</label>
          <input type="text" name="lokasi_event" id="lokasi_event" class="form-control" value="<?php echo $event['lokasi_event']; ?>" required>     
        </div>

        <button type="submit" class="btn btn-custom">Simpan</button>
      </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
